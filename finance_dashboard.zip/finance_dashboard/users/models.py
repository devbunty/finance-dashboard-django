from django.contrib.auth.models import AbstractUser
from django.db import models

class Role(models.TextChoices):
    VIEWER = "viewer"
    ANALYST = "analyst"
    ADMIN = "admin"

class User(AbstractUser):

    role = models.CharField(
        max_length=20,
        choices=Role.choices,
        default=Role.VIEWER
    )

    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.username