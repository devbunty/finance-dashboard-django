from rest_framework.views import APIView
from rest_framework.response import Response

from users.permissions import IsViewer
from .services import get_summary


class DashboardSummary(APIView):

    permission_classes = [IsViewer]

    def get(self, request):

        data = get_summary()

        return Response(data)