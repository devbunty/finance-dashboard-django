from finance.models import FinancialRecord
from django.db.models import Sum


def get_summary():

    income = FinancialRecord.objects.filter(type="income").aggregate(
        total=Sum("amount")
    )["total"] or 0

    expense = FinancialRecord.objects.filter(type="expense").aggregate(
        total=Sum("amount")
    )["total"] or 0

    balance = income - expense

    category_summary = FinancialRecord.objects.values(
        "category"
    ).annotate(
        total=Sum("amount")
    )

    return {

        "total_income": income,

        "total_expense": expense,

        "net_balance": balance,

        "category_summary": category_summary
    }