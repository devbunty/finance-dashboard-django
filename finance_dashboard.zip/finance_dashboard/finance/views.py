from rest_framework.viewsets import ModelViewSet
from .models import FinancialRecord
from .serializers import FinancialRecordSerializer
from users.permissions import IsAnalyst, IsViewer


class FinancialRecordViewSet(ModelViewSet):

    serializer_class = FinancialRecordSerializer

    queryset = FinancialRecord.objects.filter(is_deleted=False)

    def get_permissions(self):

        if self.action in ["list", "retrieve"]:
            return [IsViewer()]

        return [IsAnalyst()]

    def perform_create(self, serializer):

        serializer.save(user=self.request.user)

    def perform_destroy(self, instance):

        instance.is_deleted = True
        instance.save()