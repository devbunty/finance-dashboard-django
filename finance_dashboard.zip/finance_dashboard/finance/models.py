from django.db import models
from django.conf import settings

User = settings.AUTH_USER_MODEL

class RecordType(models.TextChoices):
    INCOME = "income"
    EXPENSE = "expense"

class FinancialRecord(models.Model):

    user = models.ForeignKey(User, on_delete=models.CASCADE)

    amount = models.DecimalField(max_digits=10, decimal_places=2)

    type = models.CharField(
        max_length=10,
        choices=RecordType.choices
    )

    category = models.CharField(max_length=100)

    date = models.DateField()

    notes = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    is_deleted = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.type} - {self.amount}"