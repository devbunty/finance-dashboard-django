from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from users.views import UserViewSet
from finance.views import FinancialRecordViewSet
from dashboard.views import DashboardSummary

router = DefaultRouter()

router.register("users", UserViewSet)

router.register("records", FinancialRecordViewSet)

urlpatterns = [

    path("admin/", admin.site.urls),

    path("api/", include(router.urls)),

    path("api/dashboard/", DashboardSummary.as_view()),
]